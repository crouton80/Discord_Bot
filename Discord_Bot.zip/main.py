import sys
from bot import run_bot
sys.stdout.reconfigure(encoding='utf-8')

if __name__ == "__main__":
    run_bot()